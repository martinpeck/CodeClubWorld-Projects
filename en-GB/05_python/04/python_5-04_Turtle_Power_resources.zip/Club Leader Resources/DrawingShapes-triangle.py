from turtle import *

shape("turtle")

forward(100)
left(120)
forward(100)
left(120)
forward(100)
left(120)

done()
