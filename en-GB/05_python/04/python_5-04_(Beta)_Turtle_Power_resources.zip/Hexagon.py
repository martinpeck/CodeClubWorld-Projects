from turtle import *

speed(11)
shape("turtle")

for count in range(8):
	forward(100)
	right(45)

done()