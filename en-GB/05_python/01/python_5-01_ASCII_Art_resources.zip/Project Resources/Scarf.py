print("Happy Birthday" + "!"*10 )

print("")
print("Here's a scarf!")
print("")

print("-|"*20)
print("|-"*20)
print("-|"*20)
print("|-"*20)
